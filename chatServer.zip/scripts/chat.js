$(document).ready(function(){

	var username = prompt("What's your name?")||"User";
	
	var socket = io(); //connect to the server that sent this page
	socket.on('connect', function(){
		socket.emit("intro", username);
	});
	
	$('#inputText').keypress(function(ev){ //send messages on 'enter'
			if(ev.which===13){
				//send message
				socket.emit("message",$(this).val());
				console.log("Message sent: " + $(this).val())
				ev.preventDefault(); //if any
				$("#chatLog").append((new Date()).toLocaleTimeString()+", "+username+": "+$(this).val()+"\n")
				$(this).val(""); //empty the input
			}
	});
	
		function userClicked(event){ //if shift key held block user, otherwise send them a private message
			if(event.originalEvent.shiftKey){
				console.log("Blocking/unblocking user " + $(this).text())
				socket.emit("blockUser", {'username':$(this).text()})
				$(this).toggleClass("blocked")
			}
			else{
				var message = prompt("Enter your private message for " + $(this).text() + ".")
				if(message){
					console.log("Private message sent to " + $(this).text())
				socket.emit("privateMessage", {"username":$(this).text(), "message":message})
			}
		}

	}

	socket.on("userList", function(data){
		console.log("userList received")
		$("#userList").empty()
		for (user in data){ //find the right user and get their list of blocked users
			if(data[user].username == username){
				var blockList = data[user].blocked
				break
			}
		}
		console.log("Blocked users: " + blockList)
		for(user in data){//If user is blocked cross them out
			console.log(data[user].username)
			$("#userList").append($("<li>" + data[user].username + "</li>").on("dblclick", userClicked))
			if(blockList.indexOf(data[user].username) > -1){
				console.log(data[user].username + " in list")
				$("#userList li").last().addClass("blocked")
			}
		/*	if(blockList.indexOf(data[user].username) == -1){ //Alternate method
				//$("#userList").append($("<li>" + data[user].username + "</li>").addClass("blocked").on("dblclick", userClicked))
			}
			else{
				//$("#userList").append($("<li>" + data[user].username + "</li>").on("dblclick", userClicked))
			}*/
		}
	})

	socket.on("privateMessage", function(data){ //display and reply to private messages
		console.log("Private message recieved from " + data.username)
		var message = prompt("Private message from " + data.username + ": " + data.message)
		if(message){
			socket.emit("privateMessage", {"username":data.username, "message":message})
		}
	})

	socket.on("message",function(data){ //display chat messages
		console.log("Message received: " + data)
		$("#chatLog").append(data+"\n");
		$('#chatLog')[0].scrollTop=$('#chatLog')[0].scrollHeight; //scroll to the bottom
	});
});