/*SocketIO based chat room. */

var http = require('http').createServer(handler);
var fs = require('fs');
var url = require('url');
var mime = require('mime-types');
var io = require('socket.io')(http);

http.listen(8080);

console.log("Chat server listening on port 8080");

function handler(req,res){ //request handler for static serving
    console.log("request for " + req.url)
	var urlObj = url.parse(req.url, true)
	var filename ="." +  urlObj.pathname

	fs.stat(filename, function(err, stats){
		if(err){
			respondErr(err)
		}
		else{
			if(stats.isDirectory()){
				filename = "./public_html/chatRoom.html"
			}
			fs.readFile(filename, function(err, data){
				if(err){
					respondErr(err)
				}	
				respond(200, data)
			})
		}
	})

	function respondErr(err){
		if(err.code == "ENOENT"){
			serve404()
		}
		else{
			respond(500, err.message)
		}
	}

	function serve404(){
		fs.readFile('./public_html/404.html', 'utf8', function(err, data){
			if(err){
				respond(500, err.message)
			}
			respond(404, data)
		})
	}

	function respond(code, data){
		res.writeHead(code, {'content-type':mime.lookup(filename) || 'text/html'})
		res.end(data)
	}

};

var clients = []
io.on("connection", function(socket){
	console.log("Got a connection");

	socket.on("intro",function(data){ //sends welcome message and tells others new user has entered
		clients.push(socket)
		socket.username = data;
		socket.blocked = []
		socket.broadcast.emit("message", timestamp()+": "+socket.username+" has entered the chatroom.");
		socket.emit("message","Welcome, "+socket.username+".");
		io.emit("userList", getUserList())
	});
		
	socket.on("message", function(data){ //sends messages
		console.log("Got message from " + socket.username + ":"+data);
		//socket.broadcast.emit("message",timestamp()+", "+socket.username+": "+data); //sends message to all users regardless of whether or not sender is blocked
		for (user in clients){ //only sends message to users who haven't blocked sender
			if(clients[user].username != socket.username && clients[user].blocked.indexOf(socket.username) == -1){
				clients[user].emit("message",timestamp()+", "+socket.username+": "+data)
				console.log("Message sent")
			}
		}
	});

	socket.on("privateMessage", function(data){ //sends private messages if the intended recipient hasn't blocked the sender
		console.log("Private message for " + data.username + " from " + socket.username)
		for (user in clients){
			if(clients[user].username == data.username && clients[user].blocked.indexOf(socket.username) == -1){
				clients[user].emit("privateMessage", {"username":socket.username, "message":data.message})
				console.log("Message sent")
				break;
			}
		}
	})

	socket.on("blockUser", function(data){ //blocks the user if they weren't already, and unblocks them if they were
		console.log(socket.username + " blocking/unblocking " + data.username)
		if(socket.blocked.indexOf(data.username) > -1){
			var index = socket.blocked.indexOf(data.username)
			socket.blocked.splice(index, 1)
			console.log("Unblocked")
			socket.emit("message", "You have unblocked private messages from " + data.username)
		}
		else{
			socket.blocked.push(data.username)
			console.log("Blocked")
			socket.emit("message", "You have blocked private messages from " + data.username)
		}
	})

	socket.on("disconnect", function(){ //tells other users the user disconnected and removes them from the list of users
		console.log(socket.username+" disconnected");
		io.emit("message", timestamp()+": "+socket.username+" disconnected.");
		clients = clients.filter(function(ele){  
          return ele!==socket;
        });
		io.emit("userList", getUserList())
	});
	
});

function timestamp(){
	return new Date().toLocaleTimeString();
}

function getUserList(){
	
	var ret = [];
	
    for(var i=0;i<clients.length;i++){

		var user = {username:clients[i].username, blocked:[]} //return each user on the list as an object with their name and the users they have blocked to maintain styling of the user list
					
		for(var j = 0; j < clients[i].blocked.length; j++){ //get blocked users
			user.blocked.push(clients[i].blocked[j])
		}

		ret.push(user);
    }
    return ret;
}