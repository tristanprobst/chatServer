This app was developed on Windows 7 in Mozilla Firefox.

To run the app, extract it and navigate into its folder in the command line. If you do not have Node and npm installed, install them. Type 'node chatServerSocketIo.js'. Open your
web browser and type 'http://localhost:8080' into the address bar. Follow on-screen instructions.